document.querySelectorAll(".read-more").forEach((button) => {
  button.addEventListener("click", function () {
    alert("Press what interest you via catagory");
  });
});
